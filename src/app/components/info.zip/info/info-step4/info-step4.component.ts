import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-step4',
  templateUrl: './info-step4.component.html',
  styleUrls: ['./info-step4.component.scss']
})
export class InfoStep4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
